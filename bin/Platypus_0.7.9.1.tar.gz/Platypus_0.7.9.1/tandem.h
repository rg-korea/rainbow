
void annotate( char* sequence, char* sizes, char* displacements, int length);
int approximate_indel_rate(int size, int displacement);
